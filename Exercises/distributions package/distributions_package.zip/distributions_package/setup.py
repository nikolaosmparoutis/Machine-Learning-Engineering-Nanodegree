from setuptools import setup

setup(name='distributions',
      version='0.1',
      description="distributions: Gaussian (mean, standard deviation)"
      " Binomial (mean, standard deviation),actions: reads data, create their PDFs, plots, addition of two Gaussians, two Binomials.",
      packages=['distributions'],
      zip_safe=False)
